//SC BY DAPZSYZ
// © RE EDIT BY DAPZSYZ
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

# ALYA MD - DAPZSYZ  
Alya - mD adalah bot WhatsApp berbasis **Baileys** yang memiliki berbagai fitur keren buat memudahkan hidup lo!  

## 🔹 **Group Room Chat Alya:** [Klik Disini](https://chat.whatsapp.com/Jx1j76KwllqLEHmTP5m8M8)  
//JAN DIUBAH

## Fitur Utama  

✅ **𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐** (Welcome, Anti-link, Auto Close Group)  
✅ **𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 𝙈𝙀𝙉𝙐** (YouTube, TikTok DLL)  
✅ **𝙎𝙏𝙄𝘾𝙆𝙀𝙍 & 𝙈𝙀𝘿𝙄𝘼** (Convert ke stiker, brat image/video)  
✅ **𝙁𝙐𝙉 𝙈𝙀𝙉𝙐 & 𝙍𝙋𝙂** (KERJA, CRAFT, BANKCEK DLL)  
✅ **𝙄𝙎𝙇𝘼𝙈𝙄 𝙈𝙀𝙉𝙐** (PENGINGAT ADZAN, PENGINGAT SHOLAT, AUTO ADZAN DLL)
#WAJIB 𝐁𝐀𝐂𝐀 !!
Edit file `settings.js` sebelum menjalankan bot:  

```---    settings.js
global.ownername = "DapzSYZ"
global.botname = "Alya - MD"
global.ownernumber = "6285772182461"
global.idSaluran = "120363402892907099@newsletter"
```  

## 𝙂𝘼𝘽𝙐𝙉𝙂 𝙆𝙊𝙈𝙐𝙉𝙄𝙏𝘼𝙎 DAPZSYZ

🔹 **𝙂𝙍𝙊𝙐𝙋 𝘾𝙃𝘼𝙏** [Klik Disini](https://chat.whatsapp.com/Jx1j76KwllqLEHmTP5m8M8)  
🔹 **𝘾𝙃𝘼𝙉𝙉𝙀𝙇 𝙊𝙍𝙄 ALYA ** [Klik Disini](https://whatsapp.com/channel/0029Vb6ACHTKQuJPBFVy6O22)  
#DILARANG HAPUS CREDITS 
#footer '© DAPZSYZ | ALYA MD'
//SC BY DAPZSYZ
// © RE EDIT BY DAPZSYZ
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 
/////////////////
const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = false //auto block 212 (true to on, false to off)
global.autokickmorroco = false //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
//////////////////////////////////////////////////////////////////////////////////

//BATAS//

//=========UBAH BAGIAN THUMBNAIL MENU & ALLMENU==========//
global.gif = fs.readFileSync('./data/image/yoimiya.mp4'),
global.thumbnail = 'https://files.catbox.moe/f61syu.jpg', //THUMB MENU KALIAN
global.dinzmenu = 'https://files.catbox.moe/f61syu.jpg', //THUMB MENU button KALIAN
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

/////////////////////// WELCOME SETTINGS ///////////////
global.wlcmimg = 'https://img1.pixhost.to/images/5177/590217282_skyzopedia.jp'
global.leftimg = 'https://img1.pixhost.to/images/5177/590217282_skyzopedia.jp'
global.wlcm = false //UNTUK AUTO WELCOMENYA
global.textwlcm = `
┌─┉─ • ─┉─  ── .✦
│𝘄𝗲𝗹𝗹𝗰𝝾𝗺𝗲 𝗻𝗲𝘄 𝗺𝗲𝗺, 𝗶𝗻𝘁𝗿𝝾 𝗱𝘂𝗹𝘂 𝘆𝘂𝗸! 
│𝗻𝝰𝗺𝝰 :
│𝝰𝘀𝗸𝝾𝘁 :
│𝘂𝗺𝘂𝗿 :
│𝗺𝝰𝗸𝝰𝘀𝗶𝗵 𝘂𝗱𝝰𝗵 𝗶𝗻𝘁𝗿𝝾 ૮₍꜆꜄ ˃ ³ ˂ ₎ა 
└─┉─¡! • !¡─┉─ ── .✦`

///////////////////)/)) FAKE REPLY/FAKE QUOTED //////////////////))/
global.replyyoimiya = 'https://files.catbox.moe/demo3e.png'
global.replyDinzID = 'https://files.catbox.moe/demo3e.png'
global.replydinz = 'https://files.catbox.moe/demo3e.png'
global.reply = 'https://files.catbox.moe/demo3e.png'

//////////////////////SETTING TAMPILAN MENU KALIAN//////////////////
global.ig = '@riixs4k' //NAMA IG LU
global.yt = 'EVILVOID TM' //NAMA YT LU, KALO GADA GAUSAH DIISI
global.ttowner = '-' //NAMA TIKTOK LU
global.ownername = 'riixs4k' //NAMA LU
global.owner = ['6283111295013'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6283111295013' // NOMOR LU
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.nameCreator = 'EVILVOID TM'
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

//=================SETTING PAYMENT KALIAN===================\\
global.nodana = '-' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '-' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '-' // KOSONG KAN JIKA TIDAK ADA
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

//==============SETTING PAYMENT NAME=======================\\
global.andana = '' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '' // KOSONG KAN JIKA TIDAK ADA
//////////////////////////////////////////////////////////////////////////////////

//BATAS//

//==================SETTING BOT===========================\\
global.botname = "EVILVOID TM" //NAMA BOT LU
global.ownernumber = '6283111295013' //NOMOR LU
global.botnumber = '6283111295013' //NOMOR LU
global.ownername = 'riixs4k' //NAMA LU
global.idSaluran = "120363400489253607@newsletter"//ID SALURAN LU
global.idch = "120363400489253607@newsletter"//ID SALURAN LU
global.chat = '120363400489253607@newsletter'
global.namaSaluran = "Konan Bot || Assistant"
global.linkSaluran = "https://whatsapp.com/channel/0029VbAl8s70VycAQ2Q0ZD2G"
global.ownerNumber = ["6283111295013@s.whatsapp.net"] //NOMORLU
global.ownerweb = ""//WEB LU//OPSIONAL
global.websitex = ""//OPSIONAL
global.wagc = "https://chat.whatsapp.com/Iis50bOKrLBIEU7KOsbDlN"
global.wach = 'https://whatsapp.com/channel/0029VbAl8s70VycAQ2Q0ZD2G'
global.saluran = "https://whatsapp.com/channel/0029VbAl8s70VycAQ2Q0ZD2G"
global.themeemoji = '🪀'
global.wm = "EVILVOID TM"
global.botscript = 'CEK YT GUA'
global.packname = "EVILVOID TM"
global.author = "\n\nEVILVOID TM \n Dev : riixs4k"
global.creator = "6283111295013@s.whatsapp.net"
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

//================== CPANEL FITUR ==========================\\
global.domain = '-' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

///////////////////Server create panel egg pm2 ///////////////////////
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
/////////////////////////////////////////////////////////////////////////////////
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
/////////////////////////////////////////////////////////////////////////////////

//BATAS//

/////////////////////////////////////////////////////////////////////////////////
global.mess = {
wait: "*_ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ ʏᴀ ᴋᴀᴋ._*",
   success: "sᴜᴋsᴇs ᴋᴀᴋ",
   on: "sᴜᴅᴀʜ ᴀᴋᴛɪғ", 
   off: "sᴜᴅᴀʜ ᴏғғ",
   query: {
       text: "ᴛᴇᴋs ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
       link: "ʟɪɴᴋ ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
   },
   error: {
       fitur: "ᴍᴏʜᴏɴ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ᴇʀᴏʀ sɪʟᴀʜᴋᴀɴ ᴄʜᴀᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ ᴀɢᴀʀ ʙɪsᴀ sᴇɢᴇʀᴀ ᴅɪᴘᴇʀʙᴀɪᴋɪ",
   },
   only: {
       group: " ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ɢʀᴏᴜᴘ",
       private: "ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ",
       owner: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       admin: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       badmin: "ᴍᴀᴀғ ᴋᴀᴋ ᴋᴀʏᴀ ɴʏᴀ ᴋᴀᴋᴀᴋ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ɪɴɪ ᴅɪ ᴋᴀʀᴇɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ",
       premium: "ᴍᴀᴀғ ᴋᴀᴍᴜ ʙᴇʟᴏᴍ ᴍᴇɴᴊᴀᴅɪ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ sɪʟᴀᴋᴀɴ ʙᴇʟɪ ᴅɪ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ᴋᴇᴛɪᴋ  .ᴏᴡɴᴇʀ",
   }
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['.']
global.sessionName = 'session' // Jangan di ubah takut nanti error
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
